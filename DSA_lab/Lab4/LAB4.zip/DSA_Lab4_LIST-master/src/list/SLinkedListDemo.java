package list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class SLinkedListDemo {
    public static void main(String[] args) {
        List<Integer> list = new SLinkedList<>();
        ArrayListDemo.demo(list);
    }
}
